require 'puppetlabs_spec_helper/module_spec_helper'

# put local configuration and setup into spec_helper_local
begin
  require 'spec_helper_local'
rescue LoadError
end
